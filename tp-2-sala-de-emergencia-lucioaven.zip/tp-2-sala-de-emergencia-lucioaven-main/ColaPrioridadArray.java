public class ColaPrioridadArray<T> implements ColaPrioridad<T> {

    // Clase interna para representar un elemento con su prioridad 
    @SuppressWarnings("hiding")
    private class ElementoPrioritario<T> {
        T datos;
        int prioridad;

        ElementoPrioritario(T datos, int prioridad) {
            this.datos = datos;
            this.prioridad = prioridad;
        }
    }

    private ElementoPrioritario<T>[] cola; 
    private int tamanio; 

    @SuppressWarnings("unchecked")
    public ColaPrioridadArray() {
        cola = new ElementoPrioritario[100]; 
        tamanio = 0; 
    }

    public void insertar(T elem, int prioridad) {
        if (estaVacia()){
            return; 
        } 
        ElementoPrioritario<T> nuevoElementoPrioritario = new ElementoPrioritario <>(elem, prioridad);
        int i = tamanio - 1;
        while (i >= 0 && cola[i].prioridad > prioridad) {
            cola[i + 1] = cola[i];  //Desplaza los elemntos un lugar a la derecha
            i--;
        }
        cola [i + 1] = nuevoElementoPrioritario; 
        tamanio++;
    }

    public T eliminar() {
        if (estaVacia()) {
            return null;
        }
        for (int i = 1; i < tamanio; i++) {
            cola[i - 1] = cola[i];
        }
        tamanio--;
        cola[tamanio] = null;
        return observar();
    }

    public T observar() {
        if(estaVacia()){
            return null;
        } 
        return cola[0].datos; //el elemento con la prioridad más alta
    }

    public boolean estaVacia() {
        return (tamanio == 0);
    }

    public int tamanio() {
        return tamanio;
    }
}
